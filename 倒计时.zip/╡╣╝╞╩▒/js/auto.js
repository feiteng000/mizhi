//自适应尺寸
var html=document.documentElement;
var WWW=html.getBoundingClientRect().width;
html.style.fontSize=WWW/15+'px';
console.log(html.style.fontSize)
//unicode转换中文
var unicode = {
    toUN: function (str) {
        return escape(str).toLocaleLowerCase().replace(/%u/gi, '\\u');
    },
    toGB: function (str) {
        return unescape(str.replace(/\\u/gi, '%u'));
    }
};
//obj转换query
var urlcode = function (par, key, encode) {
    if(par==null) return '';
    var parStr = '';
    var t = typeof (par);
    if (t == 'string' || t == 'number' || t == 'boolean') {
        parStr += '&' + key + '=' + ((encode==null||encode) ? encodeURIComponent(par) : par);
    } else {
        for (var i in par) {
            var k = key == null ? i : key + (par instanceof Array ? '[' + i + ']' : '.' + i);
            parStr += urlcode(par[i], k, encode);
        }
    }
    return parStr;
};
//取最大值、最小值 默认最大值
var faVal = function (arr, attr) {
    arr = arr || [];
    var temp = 0;
    for (var i = 0, l = arr.length; i < l; i++) {
        var cur = arr[i][attr];
        cur > temp ? temp = cur : null;
    }
    return temp;
};
//获取参数一个参数
function getQuery(){
    var userid = ''
    var url = location.search; //获取url中"?"符后的字串
    var news = '';
    if (url.indexOf("?") != -1) {  //判断是否有参数
        var str = url.substr(1); //从第一个字符开始 因为第0个是?号 获取所有除问号的所有符串
        var b = str.indexOf('&');
        if(b == -1){
            str0 = str.split("=");
            userid = str0[1]
        }
    }
}
//时间戳
//当前时间
// function fmtDate(obj){
//     var date =  new Date();
//     var y = 1900+date.getYear();
//     var m = "0"+(date.getMonth()+1);
//     var d = "0"+date.getDate();
//     return y+"-"+m.substring(m.length-2,m.length)+"-"+d.substring(d.length-2,d.length);
// }
//接口时间
    function fmtDate(timeStamp) { 
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();    
    var m = date.getMonth() + 1;    
    m = m < 10 ? ('0' + m) : m;    
    var d = date.getDate();    
    d = d < 10 ? ('0' + d) : d;    
    var h = date.getHours();  
    h = h < 10 ? ('0' + h) : h;  
    var minute = date.getMinutes();  
    var second = date.getSeconds();  
    minute = minute < 10 ? ('0' + minute) : minute;    
    second = second < 10 ? ('0' + second) : second;   
    // return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;  
    return y + '-' + m + '-' + d;  
}; 
//ajax
var httpUrl='https://app.xjaikj.com';
var videoUrl = 'https://app.xjaikj.com/backstage/';
var vrUrl = 'http://krpano.xjaikj.com/tour/';
var allUrl = 'http://gvr.xjaikj.com/tour/';
var svrUrl='http://app.xjaikj.com/XJAPI/Public/demo/?service=';
var imgUrl='http://app.xjaikj.com/backstage/attachment/';

var ajax = function(url, data, callback) {//load partial page
    url=svrUrl+url
    var xmlhttp;
    //method方式
    if(window.XMLHttpRequest){
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open('POST', url, true);
//      if(method === 'POST'){
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//      }
        xmlhttp.send(urlcode(data));
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4 && (xmlhttp.status == 200 || xmlhttp.status == 304)) {
                switch(xmlhttp.status) {
                    case 404:                             //if the url is invalid, show the 404 page
                        console.log('该页面未找到')
                        break;
                    default:
                        var parts = url.split('.');
                        if(parts.length>1 && parts[parts.length-1] == 'html'){        //only cache static html pages
                            settings.partialCache[url] = xmlhttp.responseText;        //cache partials to improve performance
                        }
                }
                var resdata=JSON.parse(unicode.toGB(xmlhttp.responseText));
                callback(resdata.data);
            }
        }
    }
    else{
        console.log('浏览器版本过低，无法运行本程序')
        callback(404, {});
    }
}
//小区 id
var globalid=49;